<body>

	<header>
		<nav>
			<div class="container">
				<div class="row">
						<?php
							foreach($data['navbar'] as $key=>$value){
								echo '<div class="col col-sm-12 col-md-4"><a href="'.$value.'">'.$key.'</a> </div>';
							}
						?>
				</div>
			</div>
		</nav>
	</header>
	
	<div class="modal fade" id="modal">
	
		<div class="modal-dialog" role="document">
		
			<div class="modal-content">
			
				<div class="modal-header">
				
					<h5 class="modal-title">Modal Demo</h5>
					
					<button type="button" class="close" data-dismiss="modal" aria-label="close"><span aria-hidden="true">&times;</span></button>
					
				
				</div>
				
				<div class="modal-body">
					<p>This is a demonstration of a modal in Bootstrap. It was triggered automatically once the page loaded.</p>
					
				</div>
				
				<div class="modal-footer">
					<button type="button" class="btn btn-primary" data-dismiss="modal">OK, cool.</button>
				</div>
			</div>
		
		</div>
	
	</div>
	
	<div class="container">
		<div class="row">
			<h1>Welcome to My Bootstrap Assignment!</h1>
		</div>
		
		<div id="carousel" class="carousel slide" data-ride="carousel">
			<ol class="carousel-indicators">
				<li data-target="carousel" data-slide="0" class="active"></li>
				<li data-target="carousel" data-slide="1" class="active"></li>
			</ol>
			
			<div class="carousel-inner" role="listbox">
				<div class="carousel-item active">
					<img src="/assets/img/policy_shipping.png" class="d-block img-fluid" alt="Shipping Policy"/>
				</div>
				
				<div class="carousel-item">
					<img src="/assets/img/policy_tracking.png" class="d-block img-fluid" alt="Tracking Guarantee"/>
				</div>
			</div>
		</div>
	</div>

	<script src="/assets/js/jquery.min.js"></script>
	<script src="/assets/js/popper.min.js"></script>
	<script src="/assets/js/bootstrap.min.js"></script>
	<script>
		$(document).ready(function(){
			$("#modal").modal({
				show:true,
				focus:true
			});
			
			$("#carousel").carousel({
				interval:3500
			});
		});
	</script>
</body>