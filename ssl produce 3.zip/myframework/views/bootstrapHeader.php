<!doctype html>
<html lang="en">
	<head>
		<meta charset="utf-8"/>
		<meta name="viewport" content="width=device-width"/>
		<link rel="stylesheet" href="/assets/css/bootstrap.min.css"/>
		<style>
			*{
				-webkit-box-sizing:border-box;
				-moz-box-sizing:border-box;
				-ms-box-sizing:border-box;
				box-sizing:border-box;
			}
		
			nav{
				text-align:center;
			}
			
			nav a{
				display:block;
				padding:1rem 3rem;
				text-decoration:none;
				
				color:#fff;
				background:#666;
				-webkit-transition:background .5s;
				-moz-transition:background .5s;
				transition:background .5s;
			}
			
			nav a:hover, nav a:active{
				background:#111;
				text-decoration:none;
				color:#fff;
			}
			
			header{
				margin:2rem auto;
			}
		</style>
		<title>Bootstrap Example</title>
	</head>
	