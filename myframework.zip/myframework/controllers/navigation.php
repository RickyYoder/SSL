<?php

	class navigation extends AppController{
	
		public function __construct(){
			
			$this->getView("navigationHeader");
			$this->getView("navigationBody");
			$this->getView("navigationFooter");
			
		}
		
	}

?>