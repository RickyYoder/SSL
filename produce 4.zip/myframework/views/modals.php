<body>
	<div class="modal fade" id="modal">
	
		<div class="modal-dialog" role="document">
		
			<div class="modal-content">
			
				<div class="modal-header">
				
					<h5 class="modal-title">Modal Demo</h5>
					
					<button type="button" class="close" data-dismiss="modal" aria-label="close"><span aria-hidden="true">&times;</span></button>
					
				
				</div>
				
				<div class="modal-body">
					<p>This is a demonstration of a modal in Bootstrap. It was triggered automatically once the page loaded.</p>
					
				</div>
				
				<div class="modal-footer">
					<button type="button" class="btn btn-primary" data-dismiss="modal">OK, cool.</button>
				</div>
			</div>
		
		</div>
	
	</div>