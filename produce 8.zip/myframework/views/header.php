<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Bootstrap Demo</title>

    <!-- Bootstrap core CSS -->
    <!--<link href="/assets/css/bootstrap.css" rel="stylesheet">-->
	
	<!--Bootstrap CDN for best results-->
	<link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet">
	<style>
		html,body{
			width:100%;
			height:100%;
			padding:0;
			margin:0;
		}
	</style>
  </head>